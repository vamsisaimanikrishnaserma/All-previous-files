package uistore;

import org.openqa.selenium.By;

public class BuilderPropertiesPageUi {
	static public By resultsHeading = By.xpath("//h1[@class='heading-5 m-0 nb__2HfkL']");

}
