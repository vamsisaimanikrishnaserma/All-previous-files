package com.app.utility;

import java.io.IOException;
import java.sql.Time;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import okio.Timeout;

public class openchrome {
	
	Readproperties read;
	WebDriver driver;
	
	public WebDriver loadDriver() throws IOException
	{
		read = new Readproperties();
		if(read.getDriverName().equals("chrome"))
		{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\91984\\eclipse-workspace\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		}
		return driver;
		
	}
	
	

}
