package com.app.utility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Exceldata {
	FileInputStream file;
	XSSFWorkbook workbook;
	XSSFSheet sheet;
	int size=2;

	public void connection() throws IOException {
		file = new FileInputStream("c\\users\\91984\\Excel\\book1.xlsx");
		workbook = new XSSFWorkbook(file);
		sheet = workbook.getSheet("Firstsheet1");
	}

	public Object[] getlogindata() throws IOException 
	{

		Object object[] = new Object[size];
		connection();
		Iterator<Row> rows = sheet.iterator();
		Row row = rows.next();
		Iterator<Cell> cells = row.iterator();
		int index = 0;
		while (cells.hasNext())
		{
			Cell cell = cells.next();
			if (cell.getStringCellValue().equals("TestData"))
			{

				index = cell.getColumnIndex();
			}
		}
	    int i=0;
		while(rows.hasNext())
		{
			row = rows.next();
			Cell cell = row.getCell(index);
			
			if(row.getCell(index)!=null&&!cell.getStringCellValue().equals("https://www.philips.co.in/"))
			{
				object[i]=cell.getStringCellValue();
		
				i++;
				
			}
		 }
		return object;
      }
	 Object object[]=new Object[size];
	 public String Textsearch() throws IOException
	 {
		
		 object=getlogindata();
		 
		 String earphone = (String)object[0];
		 
		
		return earphone;
	
	 }
	 
}
