package com.app.pageobject;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.app.utility.Exceldata;
import com.app.utility.openchrome;

import reusable.Webdriverhelper;
import uistore.PhilipsUi;

public class philipspage {

	
	
	public void searching(Webdriverhelper helper,Exceldata data, Logger log) throws IOException
	{
		
		log.info("clicking on search");
		
		helper.click(PhilipsUi.searchbutton);
		log.info("Entering earphone");
		helper.sendText(PhilipsUi.searchingtext,data.Textsearch());
		log.info("submiting");
		helper.click(PhilipsUi.submit);
		
		
	    if(helper.getText(PhilipsUi.firstReturn).contains("Headset"))
	    {
	    	
	    	assertTrue(true);
	    	
	    }
	    else
	    {
	    	assertTrue(false);
	    }
	  	
	  	
		
		
	}
	public void Automotive(Webdriverhelper helper,Logger log) throws IOException
	{
		
		log.info("Hovering on automotive");
	
		helper.click(PhilipsUi.automotive);
		System.out.println("test click");

		helper.click(PhilipsUi.carlights);
		log.info("checking");
		if(helper.getText(PhilipsUi.secondreturn).contains("Philips Automotive"))
		{
			assertTrue(true);
		}
		else
	    {
	    	assertTrue(false);
	    }
		
		
	}
	public void Airpurifier(Webdriverhelper helper,Logger log)  throws IOException
	{
		log.info("clicking on products");
		
		helper.click(PhilipsUi.products);
		
		helper.click(PhilipsUi.thirdreturn);
		log.info("checking");
		if(helper.getText(PhilipsUi.thirdreturn).contains("series 3000i"))
		{
			assertTrue(true);
		}
		else
	    {
	    	assertTrue(false);
	    }
		
		
	}

}
