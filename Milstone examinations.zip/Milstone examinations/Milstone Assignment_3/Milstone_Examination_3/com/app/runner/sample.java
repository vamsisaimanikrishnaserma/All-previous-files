package com.app.runner;

import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


import com.app.pageobject.philipspage;
import com.app.utility.Exceldata;
import com.app.utility.Readproperties;

import com.app.utility.openchrome;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import reusable.Webdriverhelper;
import uistore.PhilipsUi;

public class sample {

	private static Logger log = LogManager.getLogger(sample.class);

  
	openchrome chrome;
     WebDriver driver;
	Readproperties read;
	Webdriverhelper helper;
	Exceldata data;
     philipspage philip;
	ExtentHtmlReporter extent ;
	ExtentReports report;
	ExtentTest test;
    Listeners listen;
	
  @BeforeTest
  public void intialization() throws IOException
  {
	  
	  
	  
    
	  extent = new ExtentHtmlReporter("C:\\Users\\91984\\eclipse-workspace\\two.html");
   chrome = new openchrome();
 report = new ExtentReports();
  report.attachReporter(extent);
    
     read = new Readproperties();
     data = new Exceldata();
    

  }
  @BeforeMethod
  public void openurl() throws IOException
  {
	  
	  System.out.println("before method");
	  log.info("Intializing driver");
	  driver = chrome.loadDriver();
	  log.info("hitting the url");
		driver.get(read.geturl());
		philip = new philipspage();
		helper = new Webdriverhelper(driver);


		
		
  }
  
  
// @Test
//  public void SearchingEarphone() throws IOException
//  {
//	 test = report.createTest("validCreds");
//	
//    philip.searching(helper,data,log);
//	
//    
//  }
// @Test
// public void PhilipsAutomotive() throws IOException
// {
//	 test = report.createTest("philipsAutomotive");
//	
//   philip.Automotive(helper,log);
//	
//   
// }
@Test
public void AirPurifier() throws IOException
{
	 test = report.createTest("Airpurifier");
	
  philip.Airpurifier(helper,log);
	
  
}
  
  


 
 
@AfterMethod
public void closedriver() {
	//report.flush();
	log.info("closing the driver");
	//driver.close();
	
}
}
