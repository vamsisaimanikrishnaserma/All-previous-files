package reusable;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestResult;

import com.app.runner.sample;
import com.app.utility.openchrome;

import uistore.PhilipsUi;

public class Webdriverhelper extends sample{

static WebDriver driver;
static	WebDriver driver1;
	openchrome chrome;

	

	public Webdriverhelper(WebDriver driver) {
		this.driver = driver;
		//this.driver1=driver;
		 //System.out.println("constructor "+driver1);

	}
	public Webdriverhelper() {
		
	

	}

	public void sendText(By element, String text) throws IOException {

		driver.findElement(element).sendKeys(text);
		
		
		

	}
	public void click(By element) throws IOException {

		driver.findElement(element).click();

		

	}
	public String getText(By element) throws IOException {

		return driver.findElement(element).getText();

	}
	public WebDriver returndriver()
	{

		return driver;

	}
	public void takeSCreenshot(ITestResult result) throws IOException
	{
		
	   driver1=returndriver();
	 //  System.out.println(result.getName());
	  File src= ((TakesScreenshot)driver1).getScreenshotAs(OutputType.FILE);
	  FileUtils.copyFile(src, new File("C:\\Users\\91984\\screenshots\\"+result.getName()+".png"));
	}


}
