package uistore;

import org.openqa.selenium.By;

public class PhilipsUi {
	
	public static By searchbutton = By.cssSelector("button[class='pv-icon pv-icon-search']");	
    public static By searchingtext = By.id("search_38712");
    public static By submit=By.cssSelector("button[type='submit']");
    public static By firstReturn=By.cssSelector("span[class='CoveoExcerpt']");
	
	public static  By automotive=By.cssSelector("a[data-track-compid='n02v3']");
	public static  By carlights=By.cssSelector("a[class='pv-heading pv-body--s']");
	public static  By secondreturn=By.cssSelector("span[class='p-heading-02 p-heading-light']");
	
	public static By products = By.cssSelector("a[class='p-n02v3__mlink']");
	public static By thirdreturn = By.cssSelector("div[class='par parsys']");
	
	


}
