//Simple function without argument and return value

function hello ()
{
    console.log("This is my function")
    console.log("This is no argument and no return value function")
}

hello();
hello();
hello();


//Simple function with argument and no return value

function sum (a,b)
{
    var c =a+b
    console.log(c)
}
sum(100,34)



//simple function with argument and return value as well

function sum(a,b)
{
    var c = a+b
    return c
}

function mul(a,b)
{
    var c = a*b
    console.log(c)
}
mul(sum(10,20),10)