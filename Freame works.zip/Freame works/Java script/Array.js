// We are going to cover Array

var arr1 = ["Testing","World",11]

//All Values from an array
console.log(arr1)

//Display value of any specific index
console.log(arr1[1])

// Find number if iteams stored into arrays
 console.log(arr1.length)

 //Update value in array

 arr1[0]="QA"
 console.log(arr1[0])