// write a js program sort data in array in ascending order and then decending order

for (let i=0;i<array.length;i++){

for (let k=0;k<array.length;k++){
if(array[k]!=null) {
    if(min>array[k]){
        min = array[k];{
        pos = k;
    }
}
}
arry2[i] = min;
array[pos] = null;
min=max;
}

};

let arry = [34,2,45,67,23,6]
console.log(sort(arry));
