//This is String Handling

//var mystr = "This is Testing World"

//Finding out length of String
//var res = mystr.length
//console.log(res)

//My SubString exists in mainString and locate its index

//console.log("index of Testing -- " + mystr.indexOf("Testing"))

//Find Out last index of sustring
//console.log("Last index of Testing --" + mystr.lastIndexOf("Testing"))

//This is String Handling

//var mystr = "This is"
//var Mystr1= "Testing World"

// Convert my String to Upper case
//console .log(mystr.toLowerCase())

//Concatinate 2 String
//console.log(mystr + mystr1)

var mystr1 = "Testing World"
var l= mystr1.length

var mystr2=""

for(j=i-1;j>=0;j--)
{
    mystr2=mystr2+mystr1.charAt(j)
}
console.log(mystr2)