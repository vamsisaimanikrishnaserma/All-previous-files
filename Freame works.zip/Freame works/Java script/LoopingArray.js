// We are going to cover Array

var arr1 = ["Testing","World",11]

//Looping through an array
arr1.push("ABCD")


var len = arr1.length

for(i=0;i<len;i++)
{
    console.log(arr1[i])
}