var i=100;
var j;

console.log("Initial value of variable is " +i)


var i=10;
var j;

console.log("Initial value of variable is " +j)


i=200

console.log("change the value of variable is "+i)


//Numeric data type
var i=100.77;
console.log(i);


//String data types
var j='Hello World';
console.log(j);


//boolean data types
var k = true;
console.log(k);