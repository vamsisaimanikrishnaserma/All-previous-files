//Break KeyWord

//var numbr = 10

//for(i=1;i<=10;i++)
//{
  //  if(numbr*i==50)
    //{
      //  break;
    //}
    //else
   // {
     //   console.log(numbr*i)
    //}
///}



//continue Keyword

var numbr = 16

for(i=1;i<=10;i++)
{
    if((numbr*i)%10==0)
    {
        continue
    }
    console.log(numbr*i)
}