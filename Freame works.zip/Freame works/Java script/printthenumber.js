// write a program to enter month a number and print the number of days in month?

var getDaysInMonth = function (month,year) {
    return new Date(year, month, 0).getDate();
};

const date = new Date();
const currentYear = date.getFullYear();
const currentMonth = date.getMonth() + 1; //month

const daysInCurrentMonth = getDaysInMonth(currentYear, currentMonth);
console.log(daysInCurrentMonth); //30

const daysInJanuary = getDaysInMonth(2025, 1);
console.log(daysInJanuary); //30

const daysInSeptember = getDaysInMonth(2025, 9);
console.log(daysInSeptember); //30