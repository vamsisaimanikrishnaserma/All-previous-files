//This is String Handling

//var mystr1="Testing World"

// SubString from given String
//console.log(mystr1.substring(3,9))

//Replace Testing to QA
//console.log(mystr1.replace("Testing","QA"))



//This is String handling
 var mystr1 = "Testing World"
 var mystr2 = "testing World"

 //Compare 2 Strings
 if(mystr1==mystr2)
 {
     console.log("Same")
 }
 else
 {
     console.log("Not Same")
 }