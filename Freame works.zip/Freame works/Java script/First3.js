// compare only first 3 characters of 2 strings

var str = '012123';
var strFirstThree = str.substring(0,3);
console.log(str);
console.log(strFirstThree);