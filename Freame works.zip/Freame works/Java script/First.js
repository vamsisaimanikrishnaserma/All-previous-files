console.log("This is my single line comment");
console.log("This is my first javascript file");