//    First i am going to use only if - else
//    WE have i number and we need to check this Even Number or Odd Number

//    For assigning a value we are using =

//var inputNumber = 10

//    For assigning a value we are using ==

if(inputNumber%2==0)
{
    console.log("This is Even Number")
}
else
{
    console.log("This is Odd Number")
}


/* 
We have a number,we need to check following conditions.
-check if number is negative,display negative nuber
-if number is 0then display it's 0
-if number is positive then check it's even or odd
*/

var inputNumber =-1;

if(inputNumber<0)
{
    console.log("This is Negative Number")
}
else if(inputNumber ==0)
{
    console.log("This is zero")
}
else if(inputNumber %2 ==0)
{
    console.log("This is Even Number")
}
else if(inputNumber %2 == 1)
{
    console.log("This is Odd Number")
}



//Nested if

var inputNumber=11

if(inputNumber % 2 == 0)
{
    if(inputNumber % 10 == 0)
    {
        console.log("This is perfect Number")
    }
    else
    {
        console.log("This is Even Number")
    }
}
else
{
    console.log("This is Odd Number")
}



//Conditional OR and conditional and

var marks = -1

if(marks < 0  || marks > 100)
{
    console.log("This is invalid Marks")
}
else if(marks >=0 && marks <=30)
{
    console.log("Sorry, you are failed")
}
else if(marks>=31 && marks <=60)
{
    console.log("You are passed")
}
else
{
    console.log("Pass with Honors")
}