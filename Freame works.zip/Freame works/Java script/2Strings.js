// compare only last 10 characters of 2 strings

const str = 'VamsiKrishna';
const n=1;

console.log(str.substring(str.length - n));