// For Loop

//var numbr=24

//for(i=10;i>=1;i--)
//{
  //  console.log( numbr + " * " + i + " = " + numbr*i )
//}


//While Loop

var numbr=10;

var i = 10;
while(i>=1)
{
    console.log (numbr + " * " + i + " = " + numbr * i)
}