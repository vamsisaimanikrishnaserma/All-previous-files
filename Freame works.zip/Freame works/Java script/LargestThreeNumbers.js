// Wite a program  Largest three given numbers

function max_of_three(a, b, c)
{
    max_val = 0;
    if (a > b)
    {
        max_val = a;
    }else
    {
        max_val = b;
    }
    if (c > max_val)
    {
        max_val = c;
    }
    return max_val;
}
console.log(max_of_three(10,0,1));
console.log(max_of_three(100,-10,-20));
console.log(max_of_three(1000,540,440));