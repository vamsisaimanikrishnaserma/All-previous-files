import java.util.*;

public class ALExample {

    public static void main(String[] args) {
        List<String> I = new ArrayList<>();

        I.add("vamsi");
        I.add("sai");
        I.add("mani");
        I.add("Krishna");
        I.add("Serma");
        System.out.println("List objects are: " + I);
        I.remove("Serma");
        System.out.println("After removing Serma,List objects are " + I);
    }
}