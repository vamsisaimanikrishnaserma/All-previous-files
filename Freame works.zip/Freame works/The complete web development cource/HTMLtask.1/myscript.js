window.onload = function(){
    var ageStart=18
    var end=100;
    var options="";
    for(var v=ageStart;v<=end;v++){
        options+="<option value =\" "+v+"\">"+v+"</option>";
    }
    document.getElementById("Age").innerHTML=options
}