window.onload = function () {
    var url = document.location.href,
        params = url.split('?')[1].split('&'),
        data = {}, tmp;
    for (var i = 0, l = params.length; i < l; i++) {
         tmp = params[i].split('=');
         data[tmp[0]] = tmp[1];
    }
    document.getElementById("email").innerHTML=data["email"].toString().replace("+"," ")
    document.getElementById("fname").innerHTML=data["fname"].toString().replace("+"," ")
    document.getElementById("age").innerHTML=data["age"].toString().replace("+"," ")
    document.getElementById("gender").innerHTML=data["gender"].toString().replace("+"," ")
    document.getElementById("vote").innerHTML=data["vote"].toString().replace("+"," ")+" "+data["voted"].toString().replace("+"," ")
}