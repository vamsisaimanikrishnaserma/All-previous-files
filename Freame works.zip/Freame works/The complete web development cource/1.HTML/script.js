function onFormSubmit() {
    var formData = readFormData();
    insertNewRecord(formData);

}
function readFormData(){
    var formData = {};
    formData["Name"]=document.getElementByid("Name").value;
    formData["Father's name"]=document.getElementByid("Father's Name").value;
    formData["Gender"]=document.getElementById("Gender").value;
    formData["voting criteria"]=document.getElementById("voting criteria").value;
    return formData;
}
function insertNewRecord(data); {
    var table = document.getElementById("humanList").getElementsByTagName('tbody')[0];
    var newrow = table.insertRow(table.length);
    cell1 = newRow.inserCell(0);
    cell1.innerHTML = data.Name;
    cell2 = newRow.insertCell(1);
    cell2.innerHTML = data.fathersname;
    cell3 = newRow,inserCell(2);
    cell3.innerHTML = data.Gender;
    cell4 = newRow,insertCell(3);
    cell4.innerHTML = data.votingcriteria;
    cell4= newRow,insertCell(4);
    cell4.innerHTML = '<a>Edit</a>
                       <a>Delete</a>";
}