public class ALExample {

    public static void main(String[] args) {
        ArrayList<String> I = new ArrayList<String>();
        {
            I.add("vamsi");
            I.add("sai");
            I.add("mani");
            I.add("Krishna");
            I.add("Serma");
            System.out.println(I);
            System.out.println(I.remove("Serma"));
            System.out.println(I.isEmpty());
            System.out.println(I.size());
        }
    }
}