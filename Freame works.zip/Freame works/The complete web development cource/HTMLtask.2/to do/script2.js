const listMain = document.querySelector(".list-main");
const addMain = document.querySelector(".add-main");
const create = document.querySelector(".create");
const add = document.querySelector(".add");
const container = document.querySelector(".task-container");

add.addEventListener("click", () => {
  const element = document.createElement("textarea");
  element.className = "task";
  container.appendChild(element);
});

create.addEventListener("click", () => {
  const tasks = document.querySelectorAll(".task");
  let i = 1;
  tasks.forEach((task) => {
    const element = document.createElement("h3");
    element.innerHTML = i + ". " + task.value;
    element.className = "given-task";
    listMain.appendChild(element);
    i++;
  });
  listMain.classList.add("show-main");
  addMain.classList.add("hide-main");
});
