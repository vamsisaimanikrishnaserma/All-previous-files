const login = document.querySelector(".login");
const email = document.querySelector(".email");
const password = document.querySelector(".password");
const error = document.querySelector(".error");
login.addEventListener("click", () => {
  const inputEmail = email.value;
  const inputPass = password.value;
  const emailPattern = /[a-zA-Z0-9]{3}@[a-zA-Z]{3}\.[a-zA-Z]{3}$/;
  const passPattern =/(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8}/;
  if (inputEmail.match(emailPattern) && inputPass.match(passPattern)) {
    console.log(inputEmail);
    window.location.href = "todo.html";
  } else if (!inputEmail.match(emailPattern) && inputPass.match(passPattern)) {
    error.innerHTML = "invalid user email";
  } else if (!inputPass.match(passPattern) && inputEmail.match(emailPattern)) {
    error.innerHTML = "invalid password";
  } else {
    error.innerHTML = "invalid email and password";
  }
});
