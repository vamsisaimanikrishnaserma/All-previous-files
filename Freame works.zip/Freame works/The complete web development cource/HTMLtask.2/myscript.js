function validation(){
    console.log("data")
    var email=document.getElementById("email").value
    var password=document.getElementById("password").value
    var emailregs=/^[a-zA-Z0-9]+@[a-zA-Z0-9]+.[a-zA-Z0-9]{3}/;
    var passwordregs=/^[a-zA-Z0-9]+(?=.*[A-Z])+(?=.*[0-9])/;
    if(email.match(emailregs))
    {document.getElementById("warningemail").innerHTML="enter eamil ok"}
    else
    document.getElementById("warningemail").innerHTML="enter email not ok";
    if(password.match(passwordregs))
    {document.getElementById("warningpassword").innerHTML="enter passwod ok"}
    else
    document.getElementById("warningpassword").innerHTML="enter password not ok"

}

