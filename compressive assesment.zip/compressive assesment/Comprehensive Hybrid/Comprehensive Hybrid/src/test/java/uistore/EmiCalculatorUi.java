package uistore;

import org.openqa.selenium.By;

public class EmiCalculatorUi {
	static public By loanAmount= By.id("ae");
	static public By rateOfIntrest= By.id("ae2");
	static public By loanTenure= By.id("ae1");
	static public By monthlyEmi= By.id("ae5");
	static public By principalAmount= By.id("p_amount");
	static public By totalIntrest= By.id("t_interest");
	static public By totalAmount= By.id("t_amount");

}
