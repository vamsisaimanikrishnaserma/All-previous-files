package uistore;

import org.openqa.selenium.By;

public class SearchResultPageUi {
	static public By totalResults = By.id("propertyCount");
}
